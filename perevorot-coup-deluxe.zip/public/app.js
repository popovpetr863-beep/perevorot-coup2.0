const socket=io(),$=id=>document.getElementById(id);let state;
const RU={Duke:"Герцог",Assassin:"Убийца",Captain:"Капитан",Ambassador:"Посол",Contessa:"Графиня"};
const SY={Duke:"♛",Assassin:"☠",Captain:"⚓",Ambassador:"◈",Contessa:"♕"};
const esc=x=>String(x).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
$("create").onclick=()=>socket.emit("create",{name:username()},result);
$("join").onclick=()=>socket.emit("join",{name:username(),code:$("code").value},result);
$("start").onclick=()=>socket.emit("start");
$("copy").onclick=async()=>{await navigator.clipboard?.writeText(location.href+"?room="+state.code);$("copy").textContent="Код скопирован ✓";setTimeout(()=>$("copy").textContent="Скопировать код",1500)};
function username(){return $("name").value.trim()||"Игрок"}
function result(r){if(r.ok){$("lobby").hidden=true;$("game").hidden=false;$("status").textContent=""}else $("status").textContent=r.error}
socket.on("state",s=>{state=s;$("lobby").hidden=true;$("game").hidden=false;render()});
function render(){const me=state.me,my=state.turn===me.id;
$("room").textContent=state.code;$("myname").textContent=me.name;
$("count").textContent=state.players.length+"/6";$("start").hidden=!(state.host===me.id&&!state.started);
$("turn").textContent=state.started?(my?"ВАШ ХОД":"Ход соперника"):(state.winner?"ПОБЕДИТЕЛЬ: "+state.winner:"Ожидание игроков");
$("players").innerHTML=state.players.map(p=>`<div class="player ${p.id===me.id?"me":""}"><span class="pname">${esc(p.name)}</span><span class="coins">◆ ${p.coins}</span><div class="influences">${p.cards.map(c=>c==="lost"?"☠️":c==="hidden"?"🂠":"🎴").join(" ")}</div></div>`).join("");
$("opponents").innerHTML=state.players.filter(p=>p.id!==me.id&&p.alive).map(p=>`<div class="opcard">♟ ${esc(p.name)} · ◆ ${p.coins}</div>`).join("");
$("cards").innerHTML=me.cards.map(c=>c==="lost"?`<div class="card lost"><span class="role">Потеряно</span><span class="symbol">☠</span></div>`:`<div class="card"><span class="role">${RU[c]}</span><span class="symbol">${SY[c]}</span></div>`).join("");
renderActions(my);$("log").innerHTML=state.log.map(x=>`<div class="logline">${esc(x)}</div>`).join("");$("log").scrollTop=$("log").scrollHeight;
}
function renderActions(my){let el=$("actions");if(!state.started){el.innerHTML="";return}let q=state.pending;if(q){let actor=state.players.find(p=>p.id===q.actor),name=actor?.name||"Игрок";
 if(q.claim&&q.actor!==state.me.id){el.innerHTML=`<div class="pending">⚔ ${esc(name)} заявляет <b>${RU[q.claim]}</b><button class="danger" onclick="socket.emit('challenge')">Оспорить</button>${q.action==="foreignAid"?`<button onclick="socket.emit('block',{claim:'Duke'})">Блок Герцогом</button>`:""}${q.action==="steal"?`<button onclick="socket.emit('block',{claim:'Captain'})">Блок Капитаном</button><button onclick="socket.emit('block',{claim:'Ambassador'})">Блок Послом</button>`:""}${q.action==="assassinate"?`<button onclick="socket.emit('block',{claim:'Contessa'})">Блок Графиней</button>`:""}</div>`}
 else if(q.blockedBy&&q.blockedBy!==state.me.id){el.innerHTML=`<div class="pending">🛡 Соперник блокирует действие заявляя <b>${RU[q.blockClaim]}</b><button class="danger" onclick="socket.emit('challengeBlock')">Оспорить блок</button></div>`}
 else el.innerHTML=`<div class="pending">⏳ ${q.blockedBy?"Решается блокировка…":"Ожидаем реакцию игроков…"}</div>`;return}
 if(!my){el.innerHTML="";return}
 const ts=state.players.filter(p=>p.id!==me.id&&p.alive).map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join("");
 el.innerHTML=`<select id="target" class="target"><option value="">Цель (если нужна)</option>${ts}</select><button onclick="act('income')">Доход +1</button><button onclick="act('foreignAid')">Помощь +2</button><button onclick="act('tax')">Налог +3</button><button onclick="act('exchange')">Обмен</button><button onclick="act('steal')">Кража</button><button onclick="act('assassinate')">Убийство</button><button class="danger" onclick="act('coup')">Переворот</button>`;
}
function act(action){let t=document.getElementById("target")?.value||null;if(["steal","assassinate","coup"].includes(action)&&!t)return alert("Выберите цель");socket.emit("action",{action,targetId:t})}
const params=new URLSearchParams(location.search);if(params.get("room"))$("code").value=params.get("room").toUpperCase();