const express=require("express"),http=require("http");
const {Server}=require("socket.io");
const app=express(),server=http.createServer(app),io=new Server(server);
app.use(express.static("public")); const PORT=process.env.PORT||3000;
const ROLES=["Duke","Duke","Duke","Assassin","Assassin","Assassin","Captain","Captain","Captain","Ambassador","Ambassador","Ambassador","Contessa","Contessa","Contessa"];
const RU={Duke:"Герцог",Assassin:"Убийца",Captain:"Капитан",Ambassador:"Посол",Contessa:"Графиня"};
const CLAIM={tax:"Duke",steal:"Captain",exchange:"Ambassador",assassinate:"Assassin"};
const rooms=new Map();
const shuffle=a=>[...a].sort(()=>Math.random()-.5);
const code=()=>Math.random().toString(36).slice(2,7).toUpperCase();
const alive=p=>p?.cards?.some(c=>c.alive);
const idxs=p=>p.cards.map((c,i)=>c.alive?i:-1).filter(i=>i>=0);
function pub(p,self){return {id:p.id,name:p.name,coins:p.coins,alive:alive(p),cards:p.cards.map(c=>c.alive?(self?c.role:"hidden"):"lost")}}
function state(r,sid){let me=r.players.find(p=>p.id===sid);return {code:r.code,started:r.started,host:r.host,turn:r.players[r.turn]?.id,pending:r.pending,log:r.log.slice(-40),players:r.players.map(p=>pub(p,p.id===sid)),me:me&&pub(me,true),winner:r.winner}}
function send(r){r.players.forEach(p=>io.to(p.id).emit("state",state(r,p.id)))}
function log(r,x){r.log.push(x)}
function next(r){for(let n=1;n<=r.players.length;n++){let i=(r.turn+n)%r.players.length;if(alive(r.players[i])){r.turn=i;return}}}
function lose(r,p,i){if(!p||i==null||!p.cards[i]?.alive)return; p.cards[i].alive=false; log(r,`☠️ ${p.name} потерял влияние.`)}
function end(r){let l=r.players.filter(alive);if(l.length<=1){r.started=false;r.winner=l[0]?.name||"Никто";log(r,`🏆 ${r.winner} победил!`);return true}return false}
function start(r){let deck=shuffle(ROLES).map(role=>({role,alive:true}));r.players.forEach(p=>{p.coins=2;p.cards=[deck.pop(),deck.pop()]});r.deck=deck;r.started=true;r.winner=null;r.pending=null;r.turn=0;while(!alive(r.players[r.turn]))r.turn=(r.turn+1)%r.players.length;log(r,`🎲 Игра началась. Ходит ${r.players[r.turn].name}.`)}
function finish(r){let q=r.pending;if(!q)return;let a=r.players.find(p=>p.id===q.actor),t=r.players.find(p=>p.id===q.target);if(!a)return;
 if(q.action==="income")a.coins++;
 if(q.action==="foreignAid")a.coins+=2;
 if(q.action==="tax")a.coins+=3;
 if(q.action==="steal"&&t){let n=Math.min(2,t.coins);t.coins-=n;a.coins+=n;log(r,`🪙 ${a.name} украл ${n} монет у ${t.name}.`)}
 if(q.action==="assassinate"&&t){a.coins-=3;lose(r,t,idxs(t)[0]);log(r,`🗡️ ${a.name} совершил убийство.`)}
 if(q.action==="coup"&&t){a.coins-=7;lose(r,t,idxs(t)[0]);log(r,`💥 ${a.name} устроил переворот против ${t.name}.`)}
 if(q.action==="exchange"){let hand=a.cards.filter(c=>c.alive),draw=r.deck.splice(0,2),pool=shuffle([...hand,...draw]);a.cards=a.cards.map(c=>c.alive?pool.pop():c);r.deck.push(...pool);log(r,`🔄 ${a.name} обменял влияние.`)}
 r.pending=null;if(!end(r))next(r);send(r)}
function begin(r,a,action,targetId){if(a.coins>=10&&action!=="coup")return log(r,`⚠️ ${a.name} обязан сделать переворот.`),send(r);
 let t=targetId?r.players.find(p=>p.id===targetId):null;
 if(["steal","assassinate","coup"].includes(action)&&(!t||t===a||!alive(t)))return;
 if(action==="coup"&&a.coins<7||action==="assassinate"&&a.coins<3)return;
 let claim=CLAIM[action]||null;r.pending={actor:a.id,target:t?.id||null,action,claim,blockedBy:null,blockClaim:null,until:Date.now()+25000};
 log(r,`${a.name} выбирает действие: ${action==="tax"?"Налог":action==="steal"?"Кража":action==="assassinate"?"Убийство":action==="exchange"?"Обмен":action==="foreignAid"?"Помощь":action==="coup"?"Переворот":"Доход"}${claim?` и заявляет ${RU[claim]}`:""}.`);
 if(!claim) return finish(r),send(r); send(r); setTimeout(()=>{if(r.pending?.actor===a.id)finish(r)},25000)}
function challenge(r,sid){let q=r.pending;if(!q?.claim)return;let a=r.players.find(p=>p.id===q.actor),c=r.players.find(p=>p.id===sid);if(!a||!c||a===c)return;
 if(a.cards.some(x=>x.alive&&x.role===q.claim)){lose(r,c,idxs(c)[0]);let i=a.cards.findIndex(x=>x.alive&&x.role===q.claim),old=a.cards[i];old.alive=false;r.deck.push({role:q.claim,alive:true});a.cards[i]=r.deck.splice(Math.floor(Math.random()*r.deck.length),1)[0]||{role:q.claim,alive:true};log(r,`⚔️ ${a.name} доказал свою роль.`);r.pending=null;if(!end(r))next(r)}
 else {lose(r,a,idxs(a)[0]);log(r,`❌ ${a.name} блефовал.`);r.pending=null;if(!end(r))next(r)}
 send(r)}
function block(r,sid,claim){let q=r.pending,b=r.players.find(p=>p.id===sid);if(!q||!b||q.actor===sid)return;
 const allowed=q.action==="foreignAid"&&claim==="Duke"||q.action==="steal"&&(claim==="Captain"||claim==="Ambassador")||q.action==="assassinate"&&claim==="Contessa";if(!allowed)return;
 q.blockedBy=sid;q.blockClaim=claim;q.claim=null;log(r,`🛡️ ${b.name} блокирует действие, заявляя ${RU[claim]}.`);send(r);
 setTimeout(()=>{if(r.pending?.blockedBy===sid)finish(r)},25000)}
function challengeBlock(r,sid){let q=r.pending;if(!q?.blockedBy)return;let b=r.players.find(p=>p.id===q.blockedBy),c=r.players.find(p=>p.id===sid);if(!b||!c||b===c)return;
 if(b.cards.some(x=>x.alive&&x.role===q.blockClaim)){lose(r,c,idxs(c)[0]);log(r,`🛡️ ${b.name} доказал блокировку.`);r.pending=null;if(!end(r))next(r)}
 else {lose(r,b,idxs(b)[0]);log(r,`❌ ${b.name} блефовал с блокировкой.`);q.blockedBy=null;q.blockClaim=null;q.claim=CLAIM[q.action]||null}
 send(r)}
io.on("connection",s=>{
 s.on("create",({name},cb)=>{let c=code(),r={code:c,host:s.id,players:[],started:false,turn:0,pending:null,deck:[],log:[],winner:null};r.players.push({id:s.id,name:(name||"Игрок").slice(0,20),coins:2,cards:[]});rooms.set(c,r);s.join(c);cb({ok:true,code:c});send(r)});
 s.on("join",({name,code:c},cb)=>{let r=rooms.get(String(c||"").toUpperCase());if(!r)return cb({ok:false,error:"Комната не найдена"});if(r.started)return cb({ok:false,error:"Игра уже началась"});if(r.players.length>=6)return cb({ok:false,error:"Максимум 6 игроков"});r.players.push({id:s.id,name:(name||"Игрок").slice(0,20),coins:2,cards:[]});s.join(r.code);cb({ok:true,code:r.code});send(r)});
 s.on("start",()=>{for(let r of rooms.values())if(r.players.some(p=>p.id===s.id)&&r.host===s.id&&!r.started&&r.players.length>=2){start(r);send(r)}});
 s.on("action",({action,targetId})=>{for(let r of rooms.values())if(r.players.some(p=>p.id===s.id)){let a=r.players[r.turn];if(r.started&&!r.pending&&a?.id===s.id)begin(r,a,action,targetId);return}});
 s.on("challenge",()=>{for(let r of rooms.values())if(r.players.some(p=>p.id===s.id)){challenge(r,s.id);return}});
 s.on("block",({claim})=>{for(let r of rooms.values())if(r.players.some(p=>p.id===s.id)){block(r,s.id,claim);return}});
 s.on("challengeBlock",()=>{for(let r of rooms.values())if(r.players.some(p=>p.id===s.id)){challengeBlock(r,s.id);return}});
 s.on("disconnect",()=>{for(let r of rooms.values()){let i=r.players.findIndex(p=>p.id===s.id);if(i<0)continue;r.players.splice(i,1);if(r.host===s.id)r.host=r.players[0]?.id;if(!r.players.length){rooms.delete(r.code);continue}if(r.turn>=r.players.length)r.turn=0;send(r)}})
});
server.listen(PORT,()=>console.log("Coup Deluxe on "+PORT));